﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab02_HW
{
    public partial class DepartmentsForm : Form
    {
        private string connectionString;
        public DepartmentsForm()
        {
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["Lab02_HWConnectionString"].ConnectionString;
        }

        private void DepartmentsForm_Load(object sender, EventArgs e)
        {
            LoadDepartment();
        }

        private void LoadDepartment() 
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM tblDepartments", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO tblDepartments (DepartmentName) VALUES (@DepartmentName)", connection);
                cmd.Parameters.AddWithValue("@DepartmentName", "New Department");
                cmd.ExecuteNonQuery();
                LoadDepartment();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int departmentID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["DepartmentID"].Value);
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE tblStudents SET DepartmentName = @StudentName WHERE DepartmentID = @DepartmentID", connection);
                    cmd.Parameters.AddWithValue("@DepartmnetID", departmentID);
                    cmd.Parameters.AddWithValue("@DepartmentName", "Updated Department");
                    cmd.ExecuteNonQuery();
                    LoadDepartment();
                }

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int departmentID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["DepartmentID"].Value);
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM tblDepartments WHERE DepartmentID = @DepartmentID", connection);

                    cmd.Parameters.AddWithValue("@DepartmentID", departmentID);
                    cmd.ExecuteNonQuery();
                    LoadDepartment();
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadDepartment();
        }
    }
}
