﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab02_HW
{
    public partial class CoursesForm : Form
    {
        private string connectionString;
        public CoursesForm()
        {
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["Lab02_HWConnectionString"].ConnectionString;
        }

        private void CoursesForm_Load(object sender, EventArgs e)
        {
            LoadCourse();
        }

        private void LoadCourse() 
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM tblCourses", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO tblCourses (CourseName, Credits, DepartmentID, InstructorID) VALUES (@CourseName, @Credits, @DepartmentID, @InstructorID)", connection);
                cmd.Parameters.AddWithValue("@CourseName", "New Courses");
                cmd.Parameters.AddWithValue("@Credits", 0);
                cmd.Parameters.AddWithValue("@DepartmentID", 0);
                cmd.Parameters.AddWithValue("@IntructorID", 0);
                cmd.ExecuteNonQuery();
                LoadCourse();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int courseID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["CourseID"].Value);
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE tblCourses SET CourseName = @CourseName, Credits = @Credits, DepartmentID = @DepartmentID, InstructorID = @InstructorID WHERE CourseID = @CourseID ", connection);
                    cmd.Parameters.AddWithValue("@CourseID", courseID);
                    cmd.Parameters.AddWithValue("@CourseName", "UpdateCourseName");
                    cmd.Parameters.AddWithValue("@Credits", 0);
                    cmd.Parameters.AddWithValue("@DepartmentID", courseID);
                    cmd.Parameters.AddWithValue("@IntructorID", courseID);
                    cmd.ExecuteNonQuery();
                    LoadCourse();
                }

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int courseID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["CourseID"].Value);
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM tblCourses WHERE CourseID = @CourseID", connection);

                    cmd.Parameters.AddWithValue("@CourseID", courseID);
                    cmd.ExecuteNonQuery();
                    LoadCourse();
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadCourse();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
